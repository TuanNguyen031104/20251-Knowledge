package com.example.marsphotos.overview

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.marsphotos.network.MarsApi
import kotlinx.coroutines.launch

class OverviewViewModel: ViewModel() {
    // The internal MutableLiveData that stores the status of the most recent request
    private val _status = MutableLiveData<String>()

    // The external immutable LiveData for the request status
    val status: LiveData<String> = _status
    /**
     * Call getMarsPhotos() on init so we can display status immediately.
     */
    init {
        getMarsPhotos()
    }

    /**
     * Gets Mars photos information from the Mars API Retrofit service and updates the
     * [MarsPhoto] [List] [LiveData].
     */
    private fun getMarsPhotos() {
        //_status.value = "Set the Mars API status response here!"
        viewModelScope.launch {
            try {
                val listResult = MarsApi.retrofitService.getPhotos()
                //_status.value = listResult
                _status.value = "Success: ${listResult.size} Mars photos retrived"
            } catch (e: Exception) {
                _status.value = "Failure: ${e.message}"
            }
        }
    }
}