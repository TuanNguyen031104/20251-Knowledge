package com.example.wordsapp

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class LetterAdapter(val context: Context ) :
    RecyclerView.Adapter<LetterAdapter.LetterViewHolder>() {
    // Generates a [CharRange] from 'A' to 'Z' and converts it to a list
    private val list = ('A').rangeTo('Z').toList()

    class LetterViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        val button = view.findViewById<Button>(R.id.button_item)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LetterViewHolder {
        val layout = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.item_view, parent, false)
        return LetterViewHolder(layout)
    }

    override fun onBindViewHolder(holder: LetterViewHolder, position: Int) {
        val item = list.get(position)
        holder.button.text = item.toString()
        holder.button.setOnClickListener {
            //Toast.makeText(context, "item " + item.toString(), Toast.LENGTH_SHORT).show()
            Log.d("myLog", "item " + item.toString())
            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra("letter", holder.button.text.toString())
            context.startActivity(intent)
        }
    }
}