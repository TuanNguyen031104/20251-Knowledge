package com.example.busschedule

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.busschedule.database.AppDatabase
import com.example.busschedule.databinding.ActivityMainBinding
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        GlobalScope.launch {
            try {
                val appDatabase: AppDatabase = AppDatabase.getDatabase(applicationContext)
                val dao = appDatabase.scheduleDao()
                val listAll = dao.getAll()
                Log.d("myLog", "Tổng số bản ghi: " + listAll.size.toString())
            } catch (ex: Exception) {
                Log.d("myLog", ex.toString())
            }
            //AppDatabase.getDatabase(applicationContext).californiaParkDao().getAll()
        }
    }
}